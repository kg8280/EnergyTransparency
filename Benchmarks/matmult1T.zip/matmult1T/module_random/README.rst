Random number generation module
===============================

:scope: General Use
:description: Random number generation module

This module provides a random number generator. The generator can be seeded from
the hardware based on an asynchronous ring oscillator giving an
independent "truly random" value.
