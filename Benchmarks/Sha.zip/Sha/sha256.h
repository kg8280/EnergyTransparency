
/* Date : 18/08/2016
 * Collected and Modified from: Kyriakos Georgiou
 * Email: Kyriakos.Georgiou@bristol.ac.uk
 * Original source see below:
 * Source: https://github.com/B-Con/crypto-algorithms
 */

/*********************************************************************
* Filename:   sha256.h
* Author:     Brad Conte (brad AT bradconte.com)
* Copyright:
* Disclaimer: This code is presented "as is" without any guarantees.
* Details:    Performs known-answer tests on the corresponding SHA1
             implementation. These tests do not encompass the full
             range of available test vectors, however, if the tests
             pass it is very, very likely that the code is correct
             and was compiled properly. This code also serves as
             example usage of the functions.
*********************************************************************/

#define uchar unsigned char // 8-bit byte
#define uint unsigned int // 32-bit word

typedef struct {
   uchar data[64];
   uint datalen;
   uint bitlen[2];
   uint state[8];
} SHA256_CTX;

SHA256_CTX  sha256_transform(SHA256_CTX ctx, uchar data[]);
SHA256_CTX  sha256_init(SHA256_CTX ctx);
SHA256_CTX  sha256_update(SHA256_CTX ctx, uchar data[], uint len);
SHA256_CTX  sha256_final(SHA256_CTX ctx, uchar hash[]);
void memsetCustom( uchar data[], int c, size_t n);