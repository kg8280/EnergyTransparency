#!/usr/bin/python

import struct

def binToFloat(b):
    return struct.unpack('>f', struct.pack('>L', b))

def floatToBin(f):
    return struct.unpack('>L', struct.pack('>f', f))

def binFloatAdd(a, b):
    fa = binToFloat(a)[0]
    fb = binToFloat(b)[0]
    result = fa + fb
    binresult = floatToBin(result)[0]
    print "Hex: {:08x}, float: {:8e}".format(binresult, result)
