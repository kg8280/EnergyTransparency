/* This file is part of the work carried out for the ACM TACO submission:
  "Energy Transparency for Deeply Embedded Programs"


   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */


/* Date : 5/09/2015
 * Collected and Modified by: Kyriakos Georgiou
 * Email: Kyriakos.Georgiou@bristol.ac.uk
 * Retrieved from: http://entraproject.eu/wp-content/uploads/2014/03/deliv_5.1_final.pdf
 */

typedef struct biquadState {
    struct oneBank {
        int xn1;
        int xn2;
        int db;
    } b[BANKS+1];
} biquadState;

struct coeff { int b0, b1, b2, a1, a2; };

void initBiquads(biquadState &state);
int biquadCascade(const struct coeff &biquad, biquadState &state, int xn);

