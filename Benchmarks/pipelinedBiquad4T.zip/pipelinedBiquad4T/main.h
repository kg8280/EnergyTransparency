#define BANKS 1
#define FRACTIONALBITS 24

void main0();
