/* This file is part of the work carried out for the ACM TACO submission:
  "Energy Transparency for Deeply Embedded Programs"


   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */


/* Date : 5/09/2015
 * Author: Kyriakos Georgiou
 * Email: Kyriakos.Georgiou@bristol.ac.uk
 */

#ifndef MAC_H_
#define MAC_H_
#define DATASIZE 20
static int rnd_seed = 1;

void set_rnd_seed (int new_seed)
{
    rnd_seed = new_seed;
}

int rand_int(void)
{
    int k1;
    int ix = rnd_seed;

    k1 = ix / 127773;
    ix = 16807 * (ix - k1 * 127773) - k1 * 2836;
    if (ix < 0)
        ix += 2147483647;
    rnd_seed = ix;
    return rnd_seed;
}

void gen_random_vector(short vec[], const unsigned int len) {

    for (int x = 0; x < len; ++x) {
        vec[x] = (short) rand_int(); // random number between -128 and 127 ?
    }
}

int macCustom(const short a[], const short b[], short len, int sqr, int &sum);

#endif /* MAC_H_ */
